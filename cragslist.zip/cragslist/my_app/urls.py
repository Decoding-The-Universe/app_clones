from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.base, name='base'),
    path('new_search', views.search, name='search'),
    path('signin', views.signin, name="signin"),
    path('login', views.login, name="login")

   
   
    
        


]
